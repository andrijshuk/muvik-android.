package com.muvik.aac

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidVoice(), "AndroidTTS")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
    }

    inner class AndroidVoice {
        @JavascriptInterface
        fun speak(text: String, language: String) {
            runOnUiThread {
                if (!ttsReady || text.isBlank()) return@runOnUiThread
                val tag = when (language) {
                    "uk" -> "uk-UA"; "pl" -> "pl-PL"; "en" -> "en-US"
                    "de" -> "de-DE"; "fr" -> "fr-FR"; "es" -> "es-ES"
                    "it" -> "it-IT"; "cs" -> "cs-CZ"; "sk" -> "sk-SK"
                    "ru" -> "ru-RU"; "ro" -> "ro-RO"; "hu" -> "hu-HU"
                    "ka" -> "ka-GE"; "tr" -> "tr-TR"; "bg" -> "bg-BG"
                    "lt" -> "lt-LT"; "lv" -> "lv-LV"; "et" -> "et-EE"
                    else -> language
                }
                val locale = Locale.forLanguageTag(tag)
                val result = tts?.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "muvik_utterance")
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized) webView.evaluateJavascript("if(data.page){data.page=null;save();render()}else{AndroidTTS.speak('', 'uk')}", null)
        else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
